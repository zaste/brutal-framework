#!/usr/bin/env node

/**
 * BRUTAL Audit System - Total Framework Validation
 * Detects EVERY possible issue before optimization
 * 
 * This system:
 * 1. Tests every HTML file
 * 2. Captures all visual output
 * 3. Tracks every error (console, network, runtime)
 * 4. Measures performance metrics
 * 5. Validates component functionality
 * 6. Checks accessibility
 * 7. Monitors memory leaks
 * 8. Verifies cross-browser compatibility
 */

import puppeteer from 'puppeteer';
import { mkdir } from 'fs/promises';
import { promises as fs } from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';

const execAsync = promisify(exec);

class BrutalAuditSystem {
    constructor() {
        this.results = {
            timestamp: new Date().toISOString(),
            environment: {},
            pages: {},
            components: new Map(),
            errors: {
                runtime: [],
                console: [],
                network: [],
                validation: [],
                accessibility: [],
                performance: []
            },
            metrics: {
                coverage: { js: 0, css: 0 },
                performance: {},
                memory: {},
                accessibility: {}
            },
            insights: {
                critical: [],
                warnings: [],
                suggestions: [],
                patterns: []
            }
        };
    }

    async audit() {
        console.log('🔍 BRUTAL Audit System v1.0');
        console.log('================================\n');

        // 1. Environment check
        await this.checkEnvironment();
        
        // 2. Static analysis
        await this.staticAnalysis();
        
        // 3. Runtime testing
        await this.runtimeTesting();
        
        // 4. Performance profiling
        await this.performanceProfiling();
        
        // 5. Accessibility audit
        await this.accessibilityAudit();
        
        // 6. Memory analysis
        await this.memoryAnalysis();
        
        // 7. Cross-browser validation
        await this.crossBrowserValidation();
        
        // 8. Generate report
        await this.generateReport();
        
        console.log('\n✅ Audit complete! See brutal-audit-report.html');
    }

    async checkEnvironment() {
        console.log('📋 Checking environment...');
        
        // Check Node version
        const nodeVersion = process.version;
        
        // Check if server is running with proper headers
        try {
            const response = await fetch('http://localhost:8080/');
            const headers = response.headers;
            
            this.results.environment = {
                node: nodeVersion,
                server: {
                    running: true,
                    coep: headers.get('cross-origin-embedder-policy'),
                    coop: headers.get('cross-origin-opener-policy'),
                    cors: headers.get('access-control-allow-origin')
                }
            };
            
            // Check for SharedArrayBuffer support
            if (headers.get('cross-origin-embedder-policy') !== 'require-corp' ||
                headers.get('cross-origin-opener-policy') !== 'same-origin') {
                this.results.insights.critical.push(
                    'Server not configured for SharedArrayBuffer. Workers will fail!'
                );
            }
        } catch (error) {
            this.results.environment.server = { running: false };
            this.results.insights.critical.push('Server not running! Start with npm start');
            throw new Error('Server must be running for audit');
        }
    }

    async staticAnalysis() {
        console.log('🔎 Running static analysis...');
        
        // Analyze file structure
        const files = await this.getAllFiles('.');
        
        // Check for common issues
        for (const file of files.filter(f => f.endsWith('.js'))) {
            const content = await fs.readFile(file, 'utf-8');
            
            // Check for console.logs in production
            const consoleMatches = content.match(/console\.(log|warn|error)/g);
            if (consoleMatches && !file.includes('test')) {
                this.results.insights.warnings.push(
                    `Found ${consoleMatches.length} console statements in ${file}`
                );
            }
            
            // Check for TODO/FIXME
            const todoMatches = content.match(/\/\/\s*(TODO|FIXME|HACK)/gi);
            if (todoMatches) {
                this.results.insights.suggestions.push(
                    `Found ${todoMatches.length} TODO/FIXME in ${file}`
                );
            }
            
            // Check for potential memory leaks
            if (content.includes('addEventListener') && !content.includes('removeEventListener')) {
                this.results.insights.warnings.push(
                    `Potential memory leak in ${file}: addEventListener without cleanup`
                );
            }
        }
    }

    async runtimeTesting() {
        console.log('🚀 Running runtime tests...');
        
        const browser = await puppeteer.launch({
            headless: 'new',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--enable-features=SharedArrayBuffer',
                '--enable-precise-memory-info',
                '--js-flags=--expose-gc'
            ]
        });
        
        try {
            const files = await fs.readdir('.');
            const htmlFiles = files.filter(f => f.endsWith('.html'));
            
            for (const file of htmlFiles) {
                console.log(`  Testing ${file}...`);
                await this.testPage(browser, file);
            }
        } finally {
            await browser.close();
        }
    }

    async testPage(browser, file) {
        const page = await browser.newPage();
        const client = await page.target().createCDPSession();
        
        // Enable all domains
        await Promise.all([
            client.send('Runtime.enable'),
            client.send('Network.enable'),
            client.send('DOM.enable'),
            client.send('CSS.enable'),
            client.send('Accessibility.enable'),
            client.send('Performance.enable'),
            client.send('HeapProfiler.enable')
        ]);
        
        const pageData = {
            errors: [],
            metrics: {},
            components: [],
            accessibility: [],
            performance: {}
        };
        
        // Set up error tracking
        page.on('error', err => pageData.errors.push({ type: 'crash', message: err.message }));
        page.on('pageerror', err => pageData.errors.push({ type: 'runtime', message: err.message, stack: err.stack }));
        page.on('console', msg => {
            if (msg.type() === 'error') {
                pageData.errors.push({ type: 'console', text: msg.text() });
            }
        });
        
        // Network errors
        page.on('requestfailed', request => {
            pageData.errors.push({
                type: 'network',
                url: request.url(),
                error: request.failure().errorText
            });
        });
        
        // Start coverage
        await Promise.all([
            page.coverage.startJSCoverage(),
            page.coverage.startCSSCoverage()
        ]);
        
        try {
            // Navigate with performance tracking
            const startTime = Date.now();
            await page.goto(`http://localhost:8080/${file}`, {
                waitUntil: 'networkidle0',
                timeout: 30000
            });
            const loadTime = Date.now() - startTime;
            
            // Wait for framework
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Comprehensive page analysis
            const analysis = await page.evaluate(() => {
                const data = {
                    framework: {},
                    components: [],
                    dom: {},
                    performance: {},
                    memory: {}
                };
                
                // Framework detection
                data.framework = {
                    loaded: !!window.__BRUTAL__,
                    version: window.__BRUTAL__?.version,
                    debug: !!window.__BRUTAL__?.debug,
                    config: window.__BRUTAL__?.config || {}
                };
                
                // Component analysis
                document.querySelectorAll('*').forEach(el => {
                    if (el.tagName.includes('-')) {
                        const component = {
                            tagName: el.tagName.toLowerCase(),
                            hasState: !!el.state,
                            hasShadow: !!el.shadowRoot,
                            attributes: Array.from(el.attributes).map(a => a.name),
                            children: el.children.length,
                            events: []
                        };
                        
                        // Check for event listeners
                        const listeners = getEventListeners ? getEventListeners(el) : {};
                        component.events = Object.keys(listeners);
                        
                        data.components.push(component);
                    }
                });
                
                // DOM metrics
                data.dom = {
                    totalElements: document.querySelectorAll('*').length,
                    customElements: data.components.length,
                    shadowRoots: document.querySelectorAll('*').filter(el => el.shadowRoot).length,
                    depth: calculateDOMDepth(document.body),
                    images: document.images.length,
                    scripts: document.scripts.length,
                    styles: document.styleSheets.length
                };
                
                // Performance metrics
                data.performance = {
                    timing: performance.timing,
                    navigation: performance.navigation,
                    resources: performance.getEntriesByType('resource').length,
                    measures: performance.getEntriesByType('measure'),
                    marks: performance.getEntriesByType('mark')
                };
                
                // Memory info
                if (performance.memory) {
                    data.memory = {
                        usedJSHeapSize: performance.memory.usedJSHeapSize,
                        totalJSHeapSize: performance.memory.totalJSHeapSize,
                        jsHeapSizeLimit: performance.memory.jsHeapSizeLimit
                    };
                }
                
                // Helper function
                function calculateDOMDepth(element, depth = 0) {
                    if (!element.children.length) return depth;
                    return Math.max(...Array.from(element.children).map(
                        child => calculateDOMDepth(child, depth + 1)
                    ));
                }
                
                return data;
            });
            
            // Visual testing - interact with components
            await this.visualTesting(page, pageData);
            
            // Accessibility check
            const accessibility = await page.accessibility.snapshot();
            pageData.accessibility = this.analyzeAccessibility(accessibility);
            
            // Performance metrics
            const metrics = await page.metrics();
            pageData.performance = {
                ...metrics,
                loadTime
            };
            
            // Coverage data
            const [jsCoverage, cssCoverage] = await Promise.all([
                page.coverage.stopJSCoverage(),
                page.coverage.stopCSSCoverage()
            ]);
            
            pageData.coverage = this.calculateCoverage(jsCoverage, cssCoverage);
            
            // Memory leak detection
            await this.checkMemoryLeaks(page, pageData);
            
            // Screenshot
            await mkdir('audit-screenshots', { recursive: true });
                await page.screenshot({
                path: `audit-screenshots/${file.replace('.html', '')}.png`,
                fullPage: true
            });
            
            // Store results
            this.results.pages[file] = {
                ...pageData,
                analysis
            };
            
        } catch (error) {
            this.results.pages[file] = {
                error: error.message,
                stack: error.stack
            };
        } finally {
            await page.close();
        }
    }

    async visualTesting(page, pageData) {
        // Test all interactive elements
        const interactiveElements = await page.$$('button, a, input, select, [onclick]');
        
        for (const element of interactiveElements) {
            try {
                const tagName = await element.evaluate(el => el.tagName);
                const isVisible = await element.isIntersectingViewport();
                
                if (isVisible) {
                    // Try to interact
                    if (tagName === 'BUTTON' || tagName === 'A') {
                        await element.click();
                        await new Promise(resolve => setTimeout(resolve, 100));
                        
                        // Check for new errors
                        const currentErrors = pageData.errors.length;
                        if (pageData.errors.length > currentErrors) {
                            const newError = pageData.errors[pageData.errors.length - 1];
                            newError.trigger = `Click on ${tagName}`;
                        }
                    }
                }
            } catch (err) {
                pageData.errors.push({
                    type: 'interaction',
                    message: err.message,
                    element: await element.evaluate(el => el.outerHTML.substring(0, 100))
                });
            }
        }
    }

    analyzeAccessibility(snapshot) {
        const issues = [];
        
        function traverse(node) {
            // Check for missing alt text
            if (node.role === 'img' && !node.name) {
                issues.push({ type: 'missing-alt', element: 'image' });
            }
            
            // Check for missing labels
            if (node.role === 'textbox' && !node.name) {
                issues.push({ type: 'missing-label', element: 'input' });
            }
            
            // Check color contrast (would need more complex analysis)
            
            // Traverse children
            if (node.children) {
                node.children.forEach(traverse);
            }
        }
        
        if (snapshot) traverse(snapshot);
        return issues;
    }

    calculateCoverage(jsCoverage, cssCoverage) {
        let jsTotal = 0, jsUsed = 0;
        jsCoverage.forEach(item => {
            jsTotal += item.text.length;
            item.ranges.forEach(range => {
                jsUsed += range.end - range.start;
            });
        });
        
        let cssTotal = 0, cssUsed = 0;
        cssCoverage.forEach(item => {
            cssTotal += item.text.length;
            item.ranges.forEach(range => {
                cssUsed += range.end - range.start;
            });
        });
        
        return {
            js: jsTotal > 0 ? (jsUsed / jsTotal * 100).toFixed(2) : 0,
            css: cssTotal > 0 ? (cssUsed / cssTotal * 100).toFixed(2) : 0,
            jsBytes: { total: jsTotal, used: jsUsed },
            cssBytes: { total: cssTotal, used: cssUsed }
        };
    }

    async checkMemoryLeaks(page, pageData) {
        // Force garbage collection
        await page.evaluate(() => {
            if (window.gc) window.gc();
        });
        
        // Take initial memory snapshot
        const initialMemory = await page.evaluate(() => performance.memory);
        
        // Perform actions that might leak
        await page.evaluate(() => {
            // Create and destroy components
            for (let i = 0; i < 100; i++) {
                const el = document.createElement('div');
                document.body.appendChild(el);
                document.body.removeChild(el);
            }
        });
        
        // Force GC again
        await page.evaluate(() => {
            if (window.gc) window.gc();
        });
        
        // Check memory again
        const finalMemory = await page.evaluate(() => performance.memory);
        
        // Detect potential leak
        const memoryGrowth = finalMemory.usedJSHeapSize - initialMemory.usedJSHeapSize;
        if (memoryGrowth > 1024 * 1024) { // 1MB threshold
            pageData.errors.push({
                type: 'memory-leak',
                message: `Potential memory leak detected: ${(memoryGrowth / 1024 / 1024).toFixed(2)}MB growth`
            });
        }
    }

    async performanceProfiling() {
        console.log('📊 Performance profiling...');
        
        // Aggregate performance data
        let totalLoadTime = 0;
        let pageCount = 0;
        
        Object.entries(this.results.pages).forEach(([file, data]) => {
            if (data.performance?.loadTime) {
                totalLoadTime += data.performance.loadTime;
                pageCount++;
            }
        });
        
        this.results.metrics.performance = {
            averageLoadTime: pageCount > 0 ? totalLoadTime / pageCount : 0,
            totalPages: pageCount
        };
    }

    async accessibilityAudit() {
        console.log('♿ Running accessibility audit...');
        
        // Aggregate accessibility issues
        const allIssues = [];
        Object.entries(this.results.pages).forEach(([file, data]) => {
            if (data.accessibility?.length > 0) {
                allIssues.push(...data.accessibility.map(issue => ({
                    ...issue,
                    page: file
                })));
            }
        });
        
        this.results.metrics.accessibility = {
            totalIssues: allIssues.length,
            byType: allIssues.reduce((acc, issue) => {
                acc[issue.type] = (acc[issue.type] || 0) + 1;
                return acc;
            }, {})
        };
    }

    async memoryAnalysis() {
        console.log('💾 Analyzing memory usage...');
        
        // Aggregate memory data
        const memoryData = [];
        Object.entries(this.results.pages).forEach(([file, data]) => {
            if (data.analysis?.memory?.usedJSHeapSize) {
                memoryData.push({
                    file,
                    memory: data.analysis.memory.usedJSHeapSize / 1024 / 1024 // MB
                });
            }
        });
        
        if (memoryData.length > 0) {
            memoryData.sort((a, b) => b.memory - a.memory);
            this.results.metrics.memory = {
                highest: memoryData[0],
                average: memoryData.reduce((sum, d) => sum + d.memory, 0) / memoryData.length
            };
        }
    }

    async crossBrowserValidation() {
        console.log('🌐 Cross-browser validation...');
        
        // Check for browser-specific issues
        const issues = [];
        
        // Check all JS files for browser-specific APIs
        const files = await this.getAllFiles('.');
        for (const file of files.filter(f => f.endsWith('.js'))) {
            const content = await fs.readFile(file, 'utf-8');
            
            // Check for non-standard APIs
            const browserSpecific = [
                { api: 'webkitRequestAnimationFrame', browsers: 'Safari' },
                { api: 'mozRequestAnimationFrame', browsers: 'Firefox' },
                { api: 'msRequestAnimationFrame', browsers: 'IE' }
            ];
            
            browserSpecific.forEach(({ api, browsers }) => {
                if (content.includes(api)) {
                    issues.push(`${file} uses ${api} (${browsers} specific)`);
                }
            });
        }
        
        if (issues.length > 0) {
            this.results.insights.warnings.push(...issues);
        }
    }

    async getAllFiles(dir, files = []) {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            if (entry.isDirectory() && !entry.name.startsWith('.') && 
                !['node_modules', 'dist'].includes(entry.name)) {
                await this.getAllFiles(fullPath, files);
            } else if (entry.isFile()) {
                files.push(fullPath);
            }
        }
        
        return files;
    }

    async generateReport() {
        console.log('\n📝 Generating comprehensive report...');
        
        // Create audit-screenshots directory
        await fs.mkdir('audit-screenshots', { recursive: true });
        
        // Analyze results and generate insights
        this.analyzeResults();
        
        // Save JSON report
        await fs.writeFile(
            'brutal-audit-report.json',
            JSON.stringify(this.results, null, 2)
        );
        
        // Generate HTML report
        const html = this.generateHTMLReport();
        await fs.writeFile('brutal-audit-report.html', html);
    }

    analyzeResults() {
        // Count total errors
        let totalErrors = 0;
        Object.values(this.results.pages).forEach(page => {
            if (page.errors) totalErrors += page.errors.length;
        });
        
        // Critical issues
        if (totalErrors > 50) {
            this.results.insights.critical.push(
                `High error count: ${totalErrors} errors across all pages`
            );
        }
        
        // Coverage insights
        Object.entries(this.results.pages).forEach(([file, data]) => {
            if (data.coverage?.js < 30) {
                this.results.insights.warnings.push(
                    `Low JS coverage in ${file}: ${data.coverage.js}%`
                );
            }
        });
        
        // Performance insights
        Object.entries(this.results.pages).forEach(([file, data]) => {
            if (data.performance?.loadTime > 3000) {
                this.results.insights.warnings.push(
                    `Slow load time in ${file}: ${data.performance.loadTime}ms`
                );
            }
        });
        
        // Component patterns
        const componentUsage = new Map();
        Object.values(this.results.pages).forEach(page => {
            if (page.analysis?.components) {
                page.analysis.components.forEach(comp => {
                    const count = componentUsage.get(comp.tagName) || 0;
                    componentUsage.set(comp.tagName, count + 1);
                });
            }
        });
        
        this.results.insights.patterns.push({
            type: 'component-usage',
            data: Object.fromEntries(componentUsage)
        });
    }

    generateHTMLReport() {
        const errorCount = Object.values(this.results.errors)
            .reduce((sum, arr) => sum + arr.length, 0);
        
        return `<!DOCTYPE html>
<html>
<head>
    <title>BRUTAL Framework Audit Report</title>
    <style>
        body {
            font-family: system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #0a0a0a;
            color: #fff;
        }
        h1 { 
            color: #00ff00; 
            text-shadow: 0 0 10px #00ff00;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .subtitle {
            color: #888;
            margin-bottom: 30px;
        }
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .metric {
            background: #1a1a1a;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #333;
        }
        .metric h3 {
            margin: 0 0 10px 0;
            color: #00ff00;
        }
        .metric .value {
            font-size: 2em;
            font-weight: bold;
        }
        .error { color: #ff3333; }
        .warning { color: #ffaa00; }
        .success { color: #00ff00; }
        .section {
            background: #1a1a1a;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            border: 1px solid #333;
        }
        .page-result {
            margin: 10px 0;
            padding: 10px;
            background: #222;
            border-radius: 4px;
        }
        pre {
            background: #000;
            padding: 10px;
            overflow-x: auto;
            border-radius: 4px;
        }
        .insights {
            margin: 20px 0;
        }
        .insight {
            padding: 10px;
            margin: 5px 0;
            border-radius: 4px;
        }
        .critical { background: #330000; border: 1px solid #ff0000; }
        .warning { background: #332200; border: 1px solid #ffaa00; }
        .suggestion { background: #002233; border: 1px solid #0088ff; }
    </style>
</head>
<body>
    <h1>🔍 BRUTAL Framework Audit Report</h1>
    <div class="subtitle">Generated: ${this.results.timestamp}</div>
    
    <div class="summary">
        <div class="metric">
            <h3>Total Pages</h3>
            <div class="value">${Object.keys(this.results.pages).length}</div>
        </div>
        <div class="metric">
            <h3>Total Errors</h3>
            <div class="value ${errorCount > 0 ? 'error' : 'success'}">${errorCount}</div>
        </div>
        <div class="metric">
            <h3>Components Found</h3>
            <div class="value">${this.results.components.size}</div>
        </div>
        <div class="metric">
            <h3>Avg Load Time</h3>
            <div class="value">${this.results.metrics.performance.averageLoadTime?.toFixed(0) || 'N/A'}ms</div>
        </div>
    </div>
    
    <div class="section">
        <h2>🚨 Critical Issues</h2>
        ${this.results.insights.critical.length === 0 ? 
            '<p class="success">No critical issues found!</p>' :
            this.results.insights.critical.map(issue => 
                `<div class="insight critical">${issue}</div>`
            ).join('')
        }
    </div>
    
    <div class="section">
        <h2>⚠️ Warnings</h2>
        ${this.results.insights.warnings.length === 0 ? 
            '<p class="success">No warnings!</p>' :
            this.results.insights.warnings.map(warning => 
                `<div class="insight warning">${warning}</div>`
            ).join('')
        }
    </div>
    
    <div class="section">
        <h2>📊 Page Analysis</h2>
        ${Object.entries(this.results.pages).map(([file, data]) => `
            <div class="page-result">
                <h3>${file}</h3>
                ${data.error ? 
                    `<p class="error">Failed to test: ${data.error}</p>` :
                    `<p>
                        Errors: <span class="${data.errors?.length > 0 ? 'error' : 'success'}">${data.errors?.length || 0}</span> |
                        Coverage: JS ${data.coverage?.js || 0}%, CSS ${data.coverage?.css || 0}% |
                        Load: ${data.performance?.loadTime || 'N/A'}ms
                    </p>`
                }
            </div>
        `).join('')}
    </div>
    
    <div class="section">
        <h2>🧩 Component Usage</h2>
        <pre>${JSON.stringify(this.results.insights.patterns.find(p => p.type === 'component-usage')?.data || {}, null, 2)}</pre>
    </div>
    
    <div class="section">
        <h2>💡 Suggestions</h2>
        ${this.results.insights.suggestions.map(suggestion => 
            `<div class="insight suggestion">${suggestion}</div>`
        ).join('')}
    </div>
    
    <div class="section">
        <h2>🔧 Environment</h2>
        <pre>${JSON.stringify(this.results.environment, null, 2)}</pre>
    </div>
</body>
</html>`;
    }
}

// Run audit
if (import.meta.url === `file://${process.argv[1]}`) {
    const audit = new BrutalAuditSystem();
    audit.audit().catch(console.error);
}