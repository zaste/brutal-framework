#!/usr/bin/env node

/**
 * BRUTAL Master Test Runner
 * Runs all tests with proper error handling and reporting
 */

import { UnifiedTestSystem } from './test/UnifiedTestSystem.js';

async function runAllTests() {
    console.log('🚀 BRUTAL Framework V3 - Master Test Suite\n');
    
    const tester = new UnifiedTestSystem();
    const modes = ['quick', 'browser', 'visual', 'complete'];
    const results = {};
    
    // Check if server is running
    try {
        const response = await fetch('http://localhost:8080/');
        if (!response.ok) throw new Error('Server not responding');
    } catch (error) {
        console.error('❌ Server not running! Start with: npm start');
        process.exit(1);
    }
    
    // Run tests in each mode
    for (const mode of modes) {
        console.log(`\n📋 Running ${mode} tests...\n`);
        
        try {
            results[mode] = await tester.runUnifiedTest(mode, {
                headless: true,
                timeout: 60000,
                screenshot: true
            });
            
            console.log(`✅ ${mode} tests completed\n`);
        } catch (error) {
            console.error(`❌ ${mode} tests failed: ${error.message}\n`);
            results[mode] = { error: error.message };
        }
    }
    
    // Generate final report
    const report = {
        timestamp: new Date().toISOString(),
        results,
        summary: {
            total: 0,
            passed: 0,
            failed: 0
        }
    };
    
    // Count results
    Object.values(results).forEach(result => {
        if (result.error) {
            report.summary.failed++;
        } else if (result.summary) {
            report.summary.total += result.summary.total || 0;
            report.summary.passed += result.summary.passed || 0;
            report.summary.failed += result.summary.failed || 0;
        }
    });
    
    // Save report
    await import('fs').then(fs => 
        fs.promises.writeFile(
            'master-test-report.json',
            JSON.stringify(report, null, 2)
        )
    );
    
    // Print summary
    console.log('\n' + '='.repeat(50));
    console.log('📊 FINAL RESULTS');
    console.log('='.repeat(50));
    console.log(`Total Tests: ${report.summary.total}`);
    console.log(`Passed: ${report.summary.passed}`);
    console.log(`Failed: ${report.summary.failed}`);
    console.log('\nDetailed report: master-test-report.json');
    
    // Exit with appropriate code
    process.exit(report.summary.failed > 0 ? 1 : 0);
}

// Run tests
runAllTests().catch(console.error);
